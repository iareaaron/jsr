
This is the version 1.0 distribution of the Java(TM) API for XML Registries (JAXR).
It is designated as the Final Release of the JAXR API 1.0 specification.

Note that this distribution does not include the JAXR Reference Implementation (RI) and will not
allow you to run a JAXR program.The JAXR RI is available separately as part of the Java Web Services
Developer Pack (JWSDP) from:

http://java.sun.com/webservices/webservicespack.html


The files included are as follows:

jaxr-1_0-fr-spec.pdf: The JAXR specification version 1.0 Final Release

jaxr-api.jar: The jar file containing the compiled JAXR API classes/interfaces. Note that these are
 API classes only and not the JAXR Reference Implementation. They will allow you to compile 
 a JAXR program but they will not allow you to run the program.

jaxr-apidoc.jar: The jar file containing the Javadoc for the JAXR API classes.

jaxr-apisrc.jar: The jar file containing the source code for the JAXR API classes. Note that these are
 sources for the API classes only and not the JAXR Reference Implementation.

readme.txt: This file
